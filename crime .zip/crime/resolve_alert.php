<?php
$conn = new mysqli("localhost", "root", "", "crime_portal");

if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

// Get Alert ID from AJAX Request
if (isset($_POST['id'])) {
    $id = $_POST['id'];
    $sql = "UPDATE emergency_alerts SET status='Resolved' WHERE id=$id";
    
    if ($conn->query($sql)) {
        echo "success";
    } else {
        echo "error";
    }
}
?>
